package htl._014contactmanager.view;


import htl._014contactmanager.database.ContactRepository;
import htl._014contactmanager.model.contact;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ContactPresenter {
    private final ContactView view;

    private final ContactRepository contactRepository;
    private  final ObservableList<contact> contacts = FXCollections.observableArrayList();

    private ContactPresenter(ContactView view) {
        this.view = view;
        this.contactRepository = new ContactRepository();

        bindViewToModel();
        attachEvents();
        addListeners();
        init();

    }

    private void bindViewToModel() {
        view.getListView().setItems(contacts);
        // weitere Bindungen für Detailansicht

    }

    private void attachEvents() {
        view.getBtnSearch().setOnAction(event -> searchContact());
        view.getBtnAdd().setOnAction(event -> addContact());
        view.getBtnEdit().setOnAction(event -> editContact());
        view.getBtnsave().setOnAction(event -> saveContact());
        view.getBtnDelete().setOnAction(event -> deleteContact());

    }

    private void deleteContact() {
        contact selectedContact = view.getListView().getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            contactRepository.deleteContact(selectedContact.getId());
            contacts.remove(selectedContact);
            clearFields();
        }
    }

    private void saveContact() {
        contact selectedContact = view.getListView().getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            selectedContact.setName(view.getTfName().getText());
            selectedContact.setNumber(view.getTfTelephone().getText());
            selectedContact.setAdress(view.getTfEmail().getText());
            contactRepository.updateContact(selectedContact);
            view.getListView().refresh();
        }
    }

    private void editContact() {
        // Enable editing of the selected contact
        contact selectedContact = view.getListView().getSelectionModel().getSelectedItem();
        if (selectedContact != null) {
            view.getTfName().setEditable(true);
            view.getTfTelephone().setEditable(true);
            view.getTfEmail().setEditable(true);
        }
    }

    private void addContact() {
        String name = view.getTfName().getText();
        String phone = view.getTfTelephone().getText();
        String address = view.getTfEmail().getText();

        if (!name.isEmpty() && !phone.isEmpty() && !address.isEmpty()) {
            contactRepository.addContact(name, phone, address);

            // Refresh contacts from database
            contacts.clear();
            contacts.addAll(contactRepository.getAllContacts());
            clearFields();
        }
    }

    // Helper method to clear input fields
    private void clearFields() {
        view.getTfId().clear();
        view.getTfName().clear();
        view.getTfTelephone().clear();
        view.getTfEmail().clear();
    }

    private void searchContact() {
        String search = view.getTfSearchField().getText().toLowerCase();
        if(!search.isEmpty()){
            contacts.stream()
                    .filter(contact -> contact.getName().toLowerCase().contains(search))
                    .limit(1)
                    .forEach(contact -> {
                        view.getListView().getSelectionModel().select(contact);
                        view.getListView().scrollTo(contact);
                    });
        }
    }

    private void addListeners() {
        // regaiereun auf eine Slektion ind der liste
        view.getListView().getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue != null){
                view.getTfId().setText(String.valueOf(newValue.getId()));
                view.getTfName().setText(newValue.getName());
                view.getTfTelephone().setText(newValue.getNumber());
                view.getTfEmail().setText(newValue.getAdress());
            }
        });
    }

    private void init() {
     // load contacts from db
        contacts.clear();
        contacts.addAll(contactRepository.getAllContacts());
        view.getListView().setItems(contacts);
    }

    public static void show(Stage stage){
        ContactView view = new ContactView();
        ContactPresenter presenter = new ContactPresenter(view);

        Scene scene = new Scene(view.getRoot());
        stage.setTitle("Contact Manager");
        stage.setScene(scene);
        stage.show();
    }
}