### Start the database server

# Start the database server

java -cp .:h2-2.3.232.jar org.h2.tools.Server -ifNotExists