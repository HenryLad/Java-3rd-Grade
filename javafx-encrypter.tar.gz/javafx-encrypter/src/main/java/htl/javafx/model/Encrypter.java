package htl.javafx.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class Encrypter {

    private final StringProperty alphabet = new SimpleStringProperty();
    private final StringProperty key = new SimpleStringProperty();
    private final StringProperty plainText = new SimpleStringProperty();
    private final StringProperty encryptedText = new SimpleStringProperty();

    public Encrypter() {
        // Set standard values
        setDefaultAlphabet();
        setPlainText("");

        // Generate a new key when the alphabet changes
        alphabet.addListener((observable, oldValue, newValue) -> {
            generateRandomKey();
        });

        // Re-encrypt when the key changes
        key.addListener((observable, oldValue, newValue) -> encrypt());

        // Re-encrypt when the plaintext changes
        plainText.addListener((observable, oldValue, newValue) -> encrypt());
    }


    public String getAlphabet() {
        return alphabet.get();
    }

    public StringProperty alphabetProperty() {
        return alphabet;
    }

    public void setAlphabet(String alphabet) {
        if (alphabet == null) return;

        // Entferne doppelte Zeichen
        String uniqueAlphabet = alphabet.chars()
                .distinct() // Entfernt doppelte Zeichen
                .mapToObj(c -> String.valueOf((char) c))
                .collect(Collectors.joining());

        this.alphabet.set(uniqueAlphabet);
    }


    public String getKey() {
        return key.get();
    }

    public StringProperty keyProperty() {
        return key;
    }

    private void setKey(String newKey) {
        key.set(newKey);
    }

    public String getPlainText() {
        return plainText.get();
    }

    public StringProperty plainTextProperty() {
        return plainText;
    }

    public void setPlainText(String text) {
        plainText.set(text);
    }

    public String getEncryptedText() {
        return encryptedText.get();
    }

    public StringProperty encryptedTextProperty() {
        return encryptedText;
    }

    private void setEncryptedText(String text) {
        encryptedText.set(text);
    }

    // Set the default alphabet
    public void setDefaultAlphabet() {
        setAlphabet("abcdefghijklmnopqrstuvwxyzöäüß");
    }

    // Generate a random key from the alphabet
    public void generateRandomKey() {
        String originalAlphabet = getAlphabet();
        List<Character> shuffledAlphabet = originalAlphabet.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.toList());

        Collections.shuffle(shuffledAlphabet, new Random());

        String newKey = shuffledAlphabet.stream()
                .map(String::valueOf)
                .collect(Collectors.joining());

        setKey(newKey);
    }

    // Encrypt the plain text using the key
    public void encrypt() {
        String currentAlphabet = getAlphabet();
        String currentKey = getKey();
        String inputText = getPlainText();
        StringBuilder encryptedText = new StringBuilder();

        for (char c : inputText.toCharArray()) {
            int index = currentAlphabet.indexOf(c);
            if (index != -1) {
                encryptedText.append(currentKey.charAt(index));
            } else {
                encryptedText.append(c);
            }
        }

        setEncryptedText(encryptedText.toString());
    }
}
