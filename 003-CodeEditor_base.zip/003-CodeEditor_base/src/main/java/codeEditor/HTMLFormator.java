package codeEditor;

import java.util.Arrays;
import java.util.List;


public class HTMLFormator implements CodeFormator {

    private static final List<String> HTML_KEYWORDS = Arrays.asList(
        "html", "head", "title", "base", "link", "meta", "style", "script", "noscript", 
        "body", "section", "nav", "article", "aside", "h1", "h2", "h3", "h4", "h5", "h6", 
        "header", "footer", "address", "main", "p", "hr", "pre", "blockquote", "ol", "ul", 
        "li", "dl", "dt", "dd", "figure", "figcaption", "div", "a", "em", "strong", "small", 
        "s", "cite", "q", "dfn", "abbr", "data", "time", "code", "var", "samp", "kbd", 
        "sub", "sup", "i", "b", "u", "mark", "ruby", "rt", "rp", "bdi", "bdo", "span", 
        "br", "wbr", "ins", "del", "picture", "source", "img", "iframe", "embed", "object", 
        "param", "video", "audio", "track", "map", "area", "table", "caption", "colgroup", 
        "col", "tbody", "thead", "tfoot", "tr", "td", "th", "form", "label", "input", 
        "button", "select", "datalist", "optgroup", "option", "textarea", "output", 
        "progress", "meter", "fieldset", "legend", "details", "summary", "dialog", 
        "script", "noscript", "template", "canvas"
    );
    
    @Override
    public String format(String text) {
        StringBuilder formattedText = new StringBuilder();
        int lastWhitespace = -1;
        ConsoleColor cls = new ConsoleColor();

        for (int i = 0; i < text.length(); i++) {
 
    
            // Handle whitespace and keywords
            if (text.charAt(i) == ' ' || text.charAt(i) == '\n' || text.charAt(i) == '<' || text.charAt(i) == '>' || text.charAt(i) == '/') {
                String word = text.substring(lastWhitespace + 1, i);
                if (HTML_KEYWORDS.contains(word)) {
                    formattedText.append(cls.ANSI_RED).append(word).append(cls.ANSI_RESET);
                } else{
                    formattedText.append(word);
                }
                formattedText.append(text.charAt(i)); // Append the whitespace
                lastWhitespace = i;
            }
    
            // Handle string literals
            if (text.charAt(i) == '"') {
                int endIndex = text.indexOf('"', i + 1);
                if (endIndex != -1) {
                    formattedText.append(cls.ANSI_GREEN).append(text.substring(i, endIndex + 1)).append(cls.ANSI_RESET);
                    i = endIndex;  // Skip to the end of the string literal
                    lastWhitespace = i;
                } else {
                    formattedText.append(text.charAt(i)); // Handle unmatched quotes
                }
            }
        }
    
        // Handle the last word if there is no trailing whitespace
        if (lastWhitespace < text.length() - 1) {
            String word = text.substring(lastWhitespace + 1);
            if (HTML_KEYWORDS.contains(word)) {
                formattedText.append(cls.ANSI_BLUE).append(word).append(cls.ANSI_RESET);
            } else {
                formattedText.append(word);
            }
        }
    
        return formattedText.toString();
    }
    
}
   

