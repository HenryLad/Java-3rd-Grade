package codeEditor;

public interface CodeFormator {
      String format(String text);
}


