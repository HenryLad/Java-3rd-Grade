package codeEditor;

import java.util.Arrays;
import java.util.List;



public class CodeEditor {

    private StringBuilder text;

    private CodeType codeType;


    public CodeEditor(CodeType codeType) {
        text = new StringBuilder();
        this.codeType = codeType;
    }

    public void setCodeType(CodeType codeType) {
        this.codeType = codeType;
    }

    public void appendLine(String line) {
        text.append(line);
        text.append("\n");
    }

    public void deleteAll() {
        text.delete(0, text.length());
    }

    public void print() {
        switch (codeType) {
            case CodeType.JAVA:
                JavaFormator javaFormator = new JavaFormator();
                System.out.println(javaFormator.format(text.toString()));
                break;
            case CodeType.FORMULA:
                FormulaFormatter formulaFormatter = new FormulaFormatter();
                System.out.println(formulaFormatter.format(text.toString()));
                break;
            case CodeType.DEFAULT:
                DefaultFormator defaultFormator = new DefaultFormator();
                System.out.println(defaultFormator.format(text.toString()));
                break;
            case CodeType.HTML:
                HTMLFormator htmlFormator = new HTMLFormator();
                System.out.println(htmlFormator.format(text.toString()));
                break;
            default:
                System.err.println("Unsupported code type");
                break;
        }
    }


}
