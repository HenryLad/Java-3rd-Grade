package codeEditor;

public enum CodeType {
   FORMULA,
   HTML,
   JAVA,
   DEFAULT
}

