package codeEditor;
public class DefaultFormator implements CodeFormator {
    @Override
    public String format(String text) {
        return text;
    }
}
