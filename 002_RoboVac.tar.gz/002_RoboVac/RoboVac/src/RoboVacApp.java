
public class RoboVacApp {
   public static void main(String[] Args) {
      roboVac.Status s1 = roboVac.Status.DIRTY;
      roboVac.Status s2 = roboVac.Status.CLEAN;
      System.out.println(s1);
      System.out.println(s1.label);
      System.out.println(s1.valueOfLabel('#'));

   }
}
