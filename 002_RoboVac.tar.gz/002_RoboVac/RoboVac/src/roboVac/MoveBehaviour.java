package roboVac;

public interface MoveBehaviour {

    public void init();

    public void move(RoboVac roboVac);

}