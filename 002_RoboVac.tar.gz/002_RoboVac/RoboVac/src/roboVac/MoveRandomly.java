package roboVac;

import java.util.Random;

public class MoveRandomly implements MoveBehaviour {
   private int dirX;
   private int dirY;

   private static final int[][] DIRECTIONS = {
         // X, Y
         { 0, -1 }, // North
         { 1, 0 }, // East
         { 0, 1 }, // South
         { -1, 0 } // West
   };

   @Override
   public void init() {
      // choose dir randomly
      Random rand = new Random();
      int dir = rand.nextInt(DIRECTIONS.length);
      dirX = DIRECTIONS[dir][0];
      dirY = DIRECTIONS[dir][1];
   }

   @Override
   public void move(RoboVac roboVac) {
      // Get current position
      var room = roboVac.getRoom();

      int x, y;

      do {
         x = room.getRobotPosX() + dirX;
         y = room.getRobotPosY() + dirY;
         room.setRobot(x, y);
         init();

         if (room.GetStatus(x + 1, y) == Status.WALL && room.GetStatus(x - 1, y) == Status.WALL
               && room.GetStatus(x, y + 1) == Status.WALL) {
            dirX = 0;
            dirY = -1;
         } else if (room.GetStatus(x, y + 1) == Status.WALL && room.GetStatus(x - 1, y) == Status.WALL
               && room.GetStatus(x, y - 1) == Status.WALL) {
            dirX = 1;
            dirY = 0;
         } else if (room.GetStatus(x, y - 1) == Status.WALL && room.GetStatus(x + 1, y) == Status.WALL
               && room.GetStatus(x - 1, y) == Status.WALL) {
            dirX = 0;
            dirY = 1;
         } else if (room.GetStatus(x, y - 1) == Status.WALL && room.GetStatus(x + 1, y) == Status.WALL
               && room.GetStatus(x, y + 1) == Status.WALL) {
            dirX = -1;
            dirY = 0;
         } 
          else {
            throw new RuntimeException("Invalid Room Generation");
         }

      } while (!room.isClean());

   }
}
