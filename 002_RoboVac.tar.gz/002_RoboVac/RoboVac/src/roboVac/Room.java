package roboVac;

public class Room {
   private Status[][] layout;
   private int robotPosX;
   private int robotPosY;

   public Room(String[] layout) {
      this.layout = new Status[layout.length][layout[0].length()];
      for (int y = 0; y < layout.length; y++) {
         for (int x = 0; x < layout[0].length(); x++) {
            this.layout[y][x] = Status.valueOfLabel(layout[y].charAt(x));
         }

      }
   }

   /**
    * @param posX
    * @param posY
    */
   public void setRobot(int posX, int posY) {
      robotPosX = posX;
      robotPosY = posY;
   }
   

   public int  getRobotPosX(){
      return this.robotPosX;
   }
   
   public int  getRobotPosY(){
      return this.robotPosY;
   }

   /**
    * @param VacPosX
    * @param VacPosY
    * @return Set the position clean at the robot position
    */
   public  void setCleanAtRobotPosition(int VacPosX, int VacPosY){
      layout[VacPosY][VacPosX] = Status.CLEAN;
   }

   public Status GetStatus(int x, int y) {
      return layout[y][x];
   }

   public boolean isClean(){
      for (int y = 0; y < layout.length; y++) {
         for (int x = 0; x < layout[y].length; x++) {
            if (layout[y][x] == Status.DIRTY) {
               return false;
            }
         }
      }
      return true;
   }
   public void SetAllDirty(){
      for (int y = 0; y < layout.length; y++) {
         for (int x = 0; x < layout[y].length; x++) {
            if (layout[y][x] == Status.CLEAN) {
               layout[y][x] = Status.DIRTY;
            }
         }
      }
   }




   public String ToString() {
      StringBuilder sb = new StringBuilder();
      for (int y = 0; y < layout.length; y++) {
         for (int x = 0; x < layout[y].length; x++) {
            if (x == robotPosX && y == robotPosY) {
               sb.append("R");
            } else {
               sb.append(layout[y][x].label);
            }
         }
         sb.append("\n");
      }
      return sb.toString();
   }

}
