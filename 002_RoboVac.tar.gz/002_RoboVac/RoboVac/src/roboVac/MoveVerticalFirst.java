package roboVac;

import java.util.Random;

public class MoveVerticalFirst implements MoveBehaviour {

   private int dirX;
   private int dirY;
   private static final int[][] DIRECTIONS = {
         // X, Y
         { 0, -1 }, // North
         { 1, 0 }, // East
         { 0, 1 }, // South
         { -1, 0 } // West
   };

   @Override
   public void init() {
      // choose dir randomly
      Random rand = new Random();
      int dir = rand.nextInt(DIRECTIONS.length);
      dirX = DIRECTIONS[dir][0];
      dirY = DIRECTIONS[dir][1];
   }

   @Override
   public void move(RoboVac roboVac) {
      // Get current position
      var room = roboVac.getRoom();

      int x, y;

      do {
         x = room.getRobotPosX() + dirX;
         y = room.getRobotPosY() + dirY;

         if (room.GetStatus(x, y) == Status.WALL) {
            init();
         } else {
            room.setRobot(x, y);
         }

      } while (!room.isClean());

   }

}
