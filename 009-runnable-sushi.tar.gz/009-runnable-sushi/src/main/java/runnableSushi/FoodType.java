package runnableSushi;

public enum FoodType {
    APPETIZER,
    SUSHI
}
