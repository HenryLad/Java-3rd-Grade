package stockApp;

import date.Date;

import stock.StockList;
import stock.StockMovement;
import stock.ValuedStockMovement;
import stock.FiFoStockList;

public class Main {
    public static void main(String[] args) {
        StockList stockList = new FiFoStockList();

        // Store, Remove, Analyze
        stockList.store(new ValuedStockMovement(
                new Date(2024, 1, 7),
                100,
                12));
        stockList.store(new ValuedStockMovement(
                new Date(2024, 1, 8),
                100, 11));

        stockList.remove(new StockMovement(
                new Date(2024, 1, 9),
                30));

        System.out.println("Stock Status: \n");
        System.out.println(stockList.getStockStatus());

        stockList.store(new ValuedStockMovement(new Date(2024, 1, 10), 100, 13));

        stockList.remove(new StockMovement(new Date(2024, 1, 9), 21));

        System.out.println("Stock Status: \n");
        System.out.println(stockList.getStockStatus());

        System.out.println("\nStock Ingoings: \n");
        System.out.println(stockList.getStockIngoings());

        System.out.println("\nStock Outgoings: \n");
        System.out.println(stockList.getStockOutgoings());
    }
}
