package stock;

public class FiFoStockList extends StockListImpl {
    private Node head;
    private Node tail;

    public FiFoStockList() {
        head = null;
        tail = null;
    }

    @Override
    public void store(ValuedStockMovement valuedStockMovement) {
        Node newNode = new Node(valuedStockMovement.clone());

        if (head == null) {
            head = newNode;
        } else {
            tail.next = newNode;
        }
        tail = newNode;

        ingoings.put(valuedStockMovement.clone());
    }

    @Override
    public void remove(StockMovement stockMovement) {
        if (head == null) return;

        Node current = head;
        while (current != null && stockMovement.quantity != 0) {
            ValuedStockMovement outgoing = new ValuedStockMovement(stockMovement.date.clone(), 0, current.valuedStockMovement.pricePerUnit);

            if (current.valuedStockMovement.quantity >= stockMovement.quantity) {
                current.valuedStockMovement.quantity -= stockMovement.quantity;
                outgoing.quantity = stockMovement.quantity;
                stockMovement.quantity = 0;
            } else {
                stockMovement.quantity -= current.valuedStockMovement.quantity;
                outgoing.quantity = current.valuedStockMovement.quantity;
                head = head.next;
                if (head == null) {
                    tail = null;
                }
            }

            outgoings.put(outgoing);
            current = current.next;
        }
    }

    @Override
    public String getStockStatus() {
        StringBuilder sb = new StringBuilder();
        Node current = head;

        while (current != null) {
            sb.append(current.valuedStockMovement.toString());
            if (current.next != null) {
                sb.append("\n");
            }
            current = current.next;
        }

        return sb.toString();
    }

    private static class Node {
        ValuedStockMovement valuedStockMovement;
        Node next;

        Node(ValuedStockMovement valuedStockMovement) {
            this.valuedStockMovement = valuedStockMovement;
            this.next = null;
        }
    }
}